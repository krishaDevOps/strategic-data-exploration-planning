# Week 2 - Execution of Data Analysis Process

This folder contains the practical Python implementation for Week 2 of the Data Science with Python internship.

## Dataset

UCI Bike Sharing Dataset

Source:
https://archive.ics.uci.edu/dataset/275/bike+sharing+dataset

## What the program does

`week2_analysis.py` performs:

1. Dataset download and ingestion
2. Dataset inspection
3. Data type inspection
4. Missing-value analysis
5. Duplicate checking
6. Data cleaning
7. Data transformation
8. Outlier investigation
9. Descriptive statistics
10. Exploratory visualizations
11. Correlation analysis
12. Initial findings

## Run in VS Code

Open the terminal in this folder and run:

```bash
python -m pip install pandas numpy matplotlib seaborn
python week2_analysis.py
```

If `python` is not recognized on Windows, try:

```bash
py -m pip install pandas numpy matplotlib seaborn
py week2_analysis.py
```

The program automatically downloads the public dataset when an internet connection is available.

## Outputs

The program creates an `outputs` folder containing:

- cleaned dataset
- descriptive statistics
- missing-value report
- outlier summary
- correlation matrix
- six visualization PNG files

These outputs can be used as evidence in the Week 2 Word report.
