"""
WEEK 2 - EXECUTION OF DATA ANALYSIS PROCESS
Data Science with Python Internship

Dataset:
UCI Bike Sharing Dataset
https://archive.ics.uci.edu/dataset/275/bike+sharing+dataset

Run in VS Code:
    python week2_analysis.py

The program:
- downloads the public dataset automatically
- loads and inspects the data
- checks missing values and duplicates
- cleans and transforms the data
- investigates outliers
- calculates descriptive statistics
- creates visualizations using Pandas, Matplotlib and Seaborn
- performs correlation analysis
- saves cleaned data, statistics and charts
- prints initial findings

This is an educational Week 2 analysis. It does not claim that
correlation proves causation.
"""

from pathlib import Path
import io
import zipfile
import urllib.request
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

warnings.filterwarnings("ignore")

# ---------------------------------------------------------
# 1. PROJECT FOLDERS
# ---------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "outputs"
VIZ_DIR = OUTPUT_DIR / "visualizations"

DATA_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)
VIZ_DIR.mkdir(exist_ok=True)

DATA_URL = "https://archive.ics.uci.edu/static/public/275/bike+sharing+dataset.zip"
RAW_FILE = DATA_DIR / "hour.csv"
CLEAN_FILE = OUTPUT_DIR / "cleaned_bike_sharing.csv"
STATS_FILE = OUTPUT_DIR / "descriptive_statistics.csv"
MISSING_FILE = OUTPUT_DIR / "missing_values_report.csv"
CORRELATION_FILE = OUTPUT_DIR / "correlation_matrix.csv"
OUTLIER_FILE = OUTPUT_DIR / "outlier_summary.csv"


# ---------------------------------------------------------
# 2. DOWNLOAD DATASET
# ---------------------------------------------------------

def download_dataset():
    if RAW_FILE.exists():
        print("Dataset already exists.")
        return

    print("Downloading UCI Bike Sharing Dataset...")

    try:
        with urllib.request.urlopen(DATA_URL, timeout=60) as response:
            content = response.read()

        with zipfile.ZipFile(io.BytesIO(content)) as z:
            hour_file = next(
                name for name in z.namelist()
                if name.lower().endswith("hour.csv")
            )

            with z.open(hour_file) as source:
                RAW_FILE.write_bytes(source.read())

        print("Dataset downloaded successfully.")

    except Exception as error:
        print("\nERROR: Dataset could not be downloaded.")
        print("Please check your internet connection.")
        raise error


# ---------------------------------------------------------
# 3. LOAD DATA
# ---------------------------------------------------------

def load_data():
    df = pd.read_csv(RAW_FILE)

    print("\n" + "=" * 60)
    print("DATASET LOADED")
    print("=" * 60)

    print("Rows:", df.shape[0])
    print("Columns:", df.shape[1])

    print("\nFirst 5 rows:")
    print(df.head())

    return df


# ---------------------------------------------------------
# 4. BASIC DATA UNDERSTANDING
# ---------------------------------------------------------

def inspect_data(df):
    print("\n" + "=" * 60)
    print("DATA TYPES")
    print("=" * 60)
    print(df.dtypes)

    print("\n" + "=" * 60)
    print("DATASET INFORMATION")
    print("=" * 60)
    print(df.info())

    print("\n" + "=" * 60)
    print("DESCRIPTIVE STATISTICS")
    print("=" * 60)
    print(df.describe())

    stats = df.describe(include="all").transpose()
    stats.to_csv(STATS_FILE)

    print("\nDescriptive statistics saved to:")
    print(STATS_FILE)


# ---------------------------------------------------------
# 5. MISSING VALUES
# ---------------------------------------------------------

def check_missing_values(df):
    print("\n" + "=" * 60)
    print("MISSING VALUE ANALYSIS")
    print("=" * 60)

    missing = df.isnull().sum()
    missing_percent = (missing / len(df)) * 100

    missing_report = pd.DataFrame({
        "missing_count": missing,
        "missing_percentage": missing_percent
    })

    print(missing_report)

    missing_report.to_csv(MISSING_FILE)

    if missing.sum() == 0:
        print("\nResult: No missing values were found.")
    else:
        print("\nResult: Missing values were found and will be handled.")


# ---------------------------------------------------------
# 6. DUPLICATES
# ---------------------------------------------------------

def check_duplicates(df):
    duplicates = df.duplicated().sum()

    print("\n" + "=" * 60)
    print("DUPLICATE ANALYSIS")
    print("=" * 60)
    print("Duplicate rows:", duplicates)

    return duplicates


# ---------------------------------------------------------
# 7. DATA CLEANING
# ---------------------------------------------------------

def clean_data(df):
    data = df.copy()

    # Convert date to datetime.
    data["dteday"] = pd.to_datetime(
        data["dteday"],
        errors="coerce"
    )

    # Remove exact duplicates.
    data = data.drop_duplicates()

    # Remove rows with invalid essential values.
    data = data.dropna(
        subset=["dteday", "hr", "cnt", "temp", "hum"]
    )

    # Validate important ranges.
    data = data[
        (data["hr"].between(0, 23))
        & (data["cnt"] >= 0)
        & (data["hum"].between(0, 1))
        & (data["temp"].between(0, 1))
    ].copy()

    print("\n" + "=" * 60)
    print("DATA CLEANING")
    print("=" * 60)

    print("Rows before cleaning:", len(df))
    print("Rows after cleaning:", len(data))
    print("Rows removed:", len(df) - len(data))

    return data


# ---------------------------------------------------------
# 8. DATA TRANSFORMATION
# ---------------------------------------------------------

def transform_data(df):
    data = df.copy()

    season_map = {
        1: "Winter",
        2: "Spring",
        3: "Summer",
        4: "Fall"
    }

    weather_map = {
        1: "Clear / Partly Cloudy",
        2: "Mist / Cloudy",
        3: "Light Rain / Snow",
        4: "Heavy Rain / Snow"
    }

    data["season_name"] = data["season"].map(season_map)
    data["weather_name"] = data["weathersit"].map(weather_map)

    # Original UCI variables are normalized.
    # These are approximate conversions for easier interpretation.
    data["temperature_c"] = data["temp"] * 47 - 8
    data["feeling_temperature_c"] = data["atemp"] * 66 - 16
    data["humidity_percent"] = data["hum"] * 100
    data["windspeed_approx_kmh"] = data["windspeed"] * 67 * 3.6

    data["year"] = data["yr"].map({
        0: 2011,
        1: 2012
    })

    data["date"] = pd.to_datetime(data["dteday"])

    data["day_name"] = data["date"].dt.day_name()
    data["month_name"] = data["date"].dt.month_name()

    data["is_weekend"] = data["weekday"].isin([0, 6])

    def time_period(hour):
        if 0 <= hour <= 5:
            return "Night"
        elif 6 <= hour <= 11:
            return "Morning"
        elif 12 <= hour <= 16:
            return "Afternoon"
        elif 17 <= hour <= 20:
            return "Evening"
        return "Late Evening"

    data["time_period"] = data["hr"].apply(time_period)

    return data


# ---------------------------------------------------------
# 9. OUTLIER ANALYSIS
# ---------------------------------------------------------

def outlier_analysis(df):
    numeric_columns = [
        "cnt",
        "temperature_c",
        "humidity_percent",
        "windspeed_approx_kmh"
    ]

    results = []

    for column in numeric_columns:
        q1 = df[column].quantile(0.25)
        q3 = df[column].quantile(0.75)
        iqr = q3 - q1

        lower = q1 - 1.5 * iqr
        upper = q3 + 1.5 * iqr

        outliers = df[
            (df[column] < lower) |
            (df[column] > upper)
        ]

        results.append({
            "variable": column,
            "Q1": q1,
            "Q3": q3,
            "IQR": iqr,
            "lower_bound": lower,
            "upper_bound": upper,
            "outlier_count": len(outliers)
        })

    report = pd.DataFrame(results)
    report.to_csv(OUTLIER_FILE, index=False)

    print("\n" + "=" * 60)
    print("OUTLIER ANALYSIS")
    print("=" * 60)
    print(report.to_string(index=False))

    print(
        "\nOutliers were identified for investigation rather than "
        "automatically deleted because extreme bike demand may be real."
    )


# ---------------------------------------------------------
# 10. SAVE CLEAN DATA
# ---------------------------------------------------------

def save_clean_data(df):
    df.to_csv(CLEAN_FILE, index=False)

    print("\nCleaned dataset saved to:")
    print(CLEAN_FILE)


# ---------------------------------------------------------
# 11. VISUALIZATION 1 - RENTALS BY HOUR
# ---------------------------------------------------------

def plot_hourly_demand(df):
    hourly = df.groupby("hr")["cnt"].mean()

    plt.figure(figsize=(10, 5))
    plt.plot(
        hourly.index,
        hourly.values,
        marker="o"
    )

    plt.title("Average Bike Rentals by Hour")
    plt.xlabel("Hour of Day")
    plt.ylabel("Average Number of Rentals")
    plt.xticks(range(24))
    plt.grid(alpha=0.25)
    plt.tight_layout()

    path = VIZ_DIR / "01_rentals_by_hour.png"
    plt.savefig(path, dpi=180)
    plt.close()

    print("Created:", path)


# ---------------------------------------------------------
# 12. VISUALIZATION 2 - SEASON
# ---------------------------------------------------------

def plot_season(df):
    order = [
        "Winter",
        "Spring",
        "Summer",
        "Fall"
    ]

    plt.figure(figsize=(8, 5))

    sns.barplot(
        data=df,
        x="season_name",
        y="cnt",
        order=order,
        estimator="mean",
        errorbar=None
    )

    plt.title("Average Bike Rentals by Season")
    plt.xlabel("Season")
    plt.ylabel("Average Rentals")
    plt.tight_layout()

    path = VIZ_DIR / "02_rentals_by_season.png"
    plt.savefig(path, dpi=180)
    plt.close()

    print("Created:", path)


# ---------------------------------------------------------
# 13. VISUALIZATION 3 - WEATHER
# ---------------------------------------------------------

def plot_weather(df):
    plt.figure(figsize=(10, 5))

    sns.barplot(
        data=df,
        x="weather_name",
        y="cnt",
        estimator="mean",
        errorbar=None
    )

    plt.title("Average Bike Rentals by Weather Condition")
    plt.xlabel("Weather Condition")
    plt.ylabel("Average Rentals")
    plt.xticks(rotation=20, ha="right")
    plt.tight_layout()

    path = VIZ_DIR / "03_rentals_by_weather.png"
    plt.savefig(path, dpi=180)
    plt.close()

    print("Created:", path)


# ---------------------------------------------------------
# 14. VISUALIZATION 4 - TEMPERATURE
# ---------------------------------------------------------

def plot_temperature(df):
    sample = df.sample(
        min(5000, len(df)),
        random_state=42
    )

    plt.figure(figsize=(9, 5))

    sns.scatterplot(
        data=sample,
        x="temperature_c",
        y="cnt",
        alpha=0.35
    )

    plt.title("Temperature vs Bike Rental Demand")
    plt.xlabel("Approximate Temperature (°C)")
    plt.ylabel("Total Rentals")
    plt.tight_layout()

    path = VIZ_DIR / "04_temperature_vs_rentals.png"
    plt.savefig(path, dpi=180)
    plt.close()

    print("Created:", path)


# ---------------------------------------------------------
# 15. VISUALIZATION 5 - WORKING DAY
# ---------------------------------------------------------

def plot_working_day(df):
    labels = {
        0: "Non-working Day",
        1: "Working Day"
    }

    work = df.copy()
    work["day_type"] = work["workingday"].map(labels)

    plt.figure(figsize=(8, 5))

    sns.barplot(
        data=work,
        x="day_type",
        y="cnt",
        estimator="mean",
        errorbar=None
    )

    plt.title("Average Rentals: Working vs Non-working Days")
    plt.xlabel("Day Type")
    plt.ylabel("Average Rentals")
    plt.tight_layout()

    path = VIZ_DIR / "05_working_vs_nonworking.png"
    plt.savefig(path, dpi=180)
    plt.close()

    print("Created:", path)


# ---------------------------------------------------------
# 16. CORRELATION ANALYSIS
# ---------------------------------------------------------

def correlation_analysis(df):
    columns = [
        "cnt",
        "temperature_c",
        "humidity_percent",
        "windspeed_approx_kmh",
        "hr"
    ]

    correlation = df[columns].corr()

    correlation.to_csv(CORRELATION_FILE)

    print("\n" + "=" * 60)
    print("CORRELATION MATRIX")
    print("=" * 60)
    print(correlation.round(3))

    plt.figure(figsize=(8, 6))

    sns.heatmap(
        correlation,
        annot=True,
        fmt=".2f",
        cmap="coolwarm",
        center=0
    )

    plt.title("Correlation Matrix")
    plt.tight_layout()

    path = VIZ_DIR / "06_correlation_heatmap.png"
    plt.savefig(path, dpi=180)
    plt.close()

    print("Created:", path)

    return correlation


# ---------------------------------------------------------
# 17. INITIAL FINDINGS
# ---------------------------------------------------------

def generate_findings(df, correlation):
    print("\n" + "=" * 60)
    print("INITIAL FINDINGS")
    print("=" * 60)

    hourly = df.groupby("hr")["cnt"].mean()
    peak_hour = hourly.idxmax()
    peak_value = hourly.max()

    low_hour = hourly.idxmin()
    low_value = hourly.min()

    season = (
        df.groupby("season_name")["cnt"]
        .mean()
        .sort_values(ascending=False)
    )

    weather = (
        df.groupby("weather_name")["cnt"]
        .mean()
        .sort_values(ascending=False)
    )

    print(
        f"1. The highest average rental demand occurs around "
        f"{peak_hour}:00, with approximately {peak_value:.0f} rentals."
    )

    print(
        f"2. The lowest average rental demand occurs around "
        f"{low_hour}:00, with approximately {low_value:.0f} rentals."
    )

    print(
        f"3. The season with the highest average demand is "
        f"{season.index[0]}."
    )

    print(
        f"4. Among the recorded weather categories, "
        f"{weather.index[0]} has the highest average demand."
    )

    print(
        f"5. The correlation between temperature and rental demand "
        f"is {correlation.loc['temperature_c', 'cnt']:.3f}."
    )

    print(
        f"6. The correlation between humidity and rental demand "
        f"is {correlation.loc['humidity_percent', 'cnt']:.3f}."
    )

    print(
        "\nThese are preliminary descriptive findings. "
        "Correlation does not establish causation."
    )


# ---------------------------------------------------------
# 18. MAIN PROGRAM
# ---------------------------------------------------------

def main():
    print("\n" + "=" * 60)
    print("WEEK 2 - EXECUTION OF DATA ANALYSIS PROCESS")
    print("=" * 60)

    download_dataset()

    # Load
    df = load_data()

    # Understand
    inspect_data(df)

    # Quality checks
    check_missing_values(df)
    duplicates = check_duplicates(df)

    # Clean
    cleaned = clean_data(df)

    # Transform
    cleaned = transform_data(cleaned)

    # Outliers
    outlier_analysis(cleaned)

    # Save
    save_clean_data(cleaned)

    # Visual analysis
    print("\n" + "=" * 60)
    print("CREATING VISUALIZATIONS")
    print("=" * 60)

    plot_hourly_demand(cleaned)
    plot_season(cleaned)
    plot_weather(cleaned)
    plot_temperature(cleaned)
    plot_working_day(cleaned)

    # Correlation
    correlation = correlation_analysis(cleaned)

    # Findings
    generate_findings(cleaned, correlation)

    print("\n" + "=" * 60)
    print("WEEK 2 ANALYSIS COMPLETED SUCCESSFULLY")
    print("=" * 60)

    print("\nGenerated files:")
    print("1.", CLEAN_FILE)
    print("2.", STATS_FILE)
    print("3.", MISSING_FILE)
    print("4.", OUTLIER_FILE)
    print("5.", CORRELATION_FILE)
    print("6. Visualization folder:", VIZ_DIR)

    print(
        "\nOpen the PNG files in the visualizations folder "
        "and use them in your Week 2 report."
    )


if __name__ == "__main__":
    main()
